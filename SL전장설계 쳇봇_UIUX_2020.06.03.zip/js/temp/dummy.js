var tempText1 = '<div class="popup_wrap">\n' +
    '<a href="#" role="button" class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press" data-pid="368" data-clk="sub">tempText1</a>\n' +
    '<a href="#" role="button" class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press" data-pid="368" data-clk="unsub">해지</a>\n' +
    '<a href="http://newsstand.naver.com/?list=&pcode=368" target="_blank" class="btn_popup" data-clk="logo" data-pid="368">기사보기</a>\n' +
    '</div>'

var tempText2 = '<div class="popup_wrap">\n' +
    '<a href="#" role="button" class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press" data-pid="368" data-clk="sub">구독</a>\n' +
    '<a href="#" role="button" class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press" data-pid="368" data-clk="unsub">tempText2</a>\n' +
    '<a href="http://newsstand.naver.com/?list=&pcode=368" target="_blank" class="btn_popup" data-clk="logo" data-pid="368">기사보기</a>\n' +
    '</div>'

var tempText3 = '<div class="popup_wrap">\n' +
    '<a href="#" role="button" class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press" data-pid="368" data-clk="sub">구독</a>\n' +
    '<a href="#" role="button" class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press" data-pid="368" data-clk="unsub">해지</a>\n' +
    '<a href="http://newsstand.naver.com/?list=&pcode=368" target="_blank" class="btn_popup" data-clk="logo" data-pid="368">tempText3</a>\n' +
    '</div>'

